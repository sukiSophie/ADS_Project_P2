#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

// 最大行长度定义，可根据实际文件调整
#define MAX_LINE_LENGTH 1024

int main(int argc, char *argv[]) {
    FILE *input_file, *output_file;
    char line[MAX_LINE_LENGTH];
    int node1, node2, weight;
    int count = 0;

    // 检查命令行参数（只需要输入文件）
    if (argc != 2) {
        fprintf(stderr, "Usage: %s <input_file.gr>\n", argv[0]);
        return 1;
    }

    // 打开输入文件
    input_file = fopen(argv[1], "r");
    if (input_file == NULL) {
        perror("Failed to open input file");
        return 1;
    }

    // 打开输出文件（固定为data.txt）
    output_file = fopen("data.txt", "w");
    if (output_file == NULL) {
        perror("Failed to open output file");
        fclose(input_file);
        return 1;
    }

    // 逐行读取文件
    while (fgets(line, MAX_LINE_LENGTH, input_file) != NULL) {
        // 去除行尾的换行符
        size_t len = strlen(line);
        if (len > 0 && line[len - 1] == '\n') {
            line[len - 1] = '\0';
        }

        // 跳过空行
        if (line[0] == '\0') {
            continue;
        }

        // 跳过注释行（以c或#开头）
        if (line[0] == 'c' || line[0] == '#') {
            continue;
        }

        // 处理问题定义行（p开头），这里仅作提示，不输出
        if (line[0] == 'p') {
            printf("Detected graph definition: %s\n", line);
            continue;
        }

        // 处理节点坐标行（n开头），这里跳过
        if (line[0] == 'n') {
            continue;
        }

        // 处理边数据行（a开头）
        if (line[0] == 'a') {
            // 格式：a 节点1 节点2 权重
            if (sscanf(line, "a %d %d %d", &node1, &node2, &weight) == 3) {
                // 输出到文件，格式：节点1id 节点2id 权重
                fprintf(output_file, "%d %d %d\n", node1, node2, weight);
                count++;
            } else {
                fprintf(stderr, "Invalid edge data line: %s\n", line);
            }
        }
    }

    // 关闭文件 
    fclose(input_file);
    fclose(output_file);

    printf("Processing completed, extracted %d edge data in total\n", count);
    return 0;
}