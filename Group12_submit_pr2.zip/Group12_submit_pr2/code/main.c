/*
 * main.c
 *
 * 功能：用堆实现最短路径算法
 * 调用现有的独立程序来完成各个功能模块
 */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

// 函数声明
void show_menu();
void create_txt(char* input_file);
void compile_and_run_fib();
void compile_and_run_bin();

int main() {
    int choice;

    printf("=== Shortest Path Algorithm with Heaps ===\n");

    char filename[512];  // 定义字符数组存储文件名（长度根据需求调整）
    
    // 提示用户输入文件名
    printf("Please enter the .gr file you want to detect: ");
    
    fgets(filename, sizeof(filename), stdin);
    filename[strcspn(filename, "\n")] = '\0';
    create_txt(filename);

    while (1) {
        show_menu();
        printf("Enter your choice (1-3): ");

        if (scanf("%d", &choice) != 1) {
            printf("Invalid input. Please enter a number.\n");
            // 清空输入缓冲区
            while (getchar() != '\n');
            continue;
        }

        switch (choice) {
            case 1:
                compile_and_run_fib();
                break;
            case 2:
                compile_and_run_bin();
                break;
            case 3:
                printf("Exiting...\n");
                exit(0);
            default:
                printf("Invalid choice. Please enter a number between 1 and 3.\n");
        }
    }

    return 0;
}

void show_menu() {
    printf("\n=== Choose your option to detect the file ===\n");
    printf("1. Finbonacci Heap \n");
    printf("2. Binary Heap\n");
    printf("3. Exit\n");
}


void create_txt(char* input_file) {
    // 检查reading可执行文件是否存在
    if (access("./reading", F_OK) != 0) {
        printf("Compiling reading.c...\n");

        int result = system("gcc reading.c -o reading");
        if (result != 0) {
            printf("Failed to compile reading.c\n");
            return;
        }
    }

    char command[512];
    sprintf(command, "reading \"%s\"", input_file);

    int result = system(command);
    if (result == 0) {
        printf("reading successfully.\n");
    } else {
        printf("reading failed.\n");
    }
}

void compile_and_run_fib() {
    // 检查可执行文件是否已存在
    if (access("./main_fib", F_OK) != 0) {
        printf("Compiling main_fib.c...\n");
        // 编译命令：源文件在前，输出可执行文件在后
        int compile_result = system("gcc -o test_fib main_fib.c Graph.c FibonacciHeap.c -std=c11 -O3 -lm");
        if (compile_result != 0) {
            printf("Failed to compile main_fib.c\n");
            return;
        }
    }
    
    int test_count;

    printf("Please enter the number of test runs(a positive number):  ");
    while (1) {
        if (scanf("%d", &test_count) != 1 || test_count <= 0) {
            printf("Invalid input. Please enter a positive integer: ");
            // 清空输入缓冲区
            while (getchar() != '\n');
        } else {
            // 清空输入缓冲区中残留的换行符
            while (getchar() != '\n');
            break;
        }
    }
    char command[512];
    sprintf(command, "test_fib data.txt \"%d\"", test_count);

    // 运行可执行文件（无输入参数，直接执行）
    printf("Running main_fib...\n");
    int run_result = system(command);
    if (run_result == 0) {
        printf("main_fib executed successfully.\n");
    } else {
        printf("main_fib execution failed.\n");
    }
}

// 编译并运行 main_bin.c（无输入参数）
void compile_and_run_bin() {
    // 检查可执行文件是否已存在
    if (access("./main_bin", F_OK) != 0) {
        printf("Compiling main_bin.c...\n");
        // 编译命令：源文件在前，输出可执行文件在后
        int compile_result = system("gcc -o test_bin main_bin.c -O3");
        if (compile_result != 0) {
            printf("Failed to compile main_bin.c\n");
            return;
        }
    }

    int test_count;

    printf("Please enter the number of test runs(a positive number):  ");
    while (1) {
        if (scanf("%d", &test_count) != 1 || test_count <= 0) {
            printf("Invalid input. Please enter a positive integer: ");
            // 清空输入缓冲区
            while (getchar() != '\n');
        } else {
            // 清空输入缓冲区中残留的换行符
            while (getchar() != '\n');
            break;
        }
    }
    char command[512];
    sprintf(command, "test_bin data.txt \"%d\"", test_count);
    // 运行可执行文件（无输入参数，直接执行）
    printf("Running main_bin...\n");
    int run_result = system(command);
    if (run_result == 0) {
        printf("main_bin executed successfully.\n");
    } else {
        printf("main_bin execution failed.\n");
    }
}

