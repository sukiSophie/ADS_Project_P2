How to use(based on Ubuntu System):
1. gcc -o main main.c

2. main

3. Then you only need to enter the .gr file name. then do as the menu shows. 
Enter 1, you can test with Fibonacci Heap.
Enter 2, you can test with Binary Heap. 
Enter 3, you can exit.
If you enter 1or2, then enter 1000 or a lager number to dicide number of tests.



How to test correctness:
1. gcc -o test dijkstra_verifier.c

2. if you have use main once , enter 'test data.txt 1 5' ,or you can create a .txt file in "1id 2id destination" format ,then use its filename to repalce "data.txt"

3. Then you can see whether the program is correct